# My AI Project
This project demonstrates a simple AI-driven system.
